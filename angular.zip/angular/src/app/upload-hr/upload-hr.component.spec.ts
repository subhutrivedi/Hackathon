import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadHrComponent } from './upload-hr.component';

describe('UploadHrComponent', () => {
  let component: UploadHrComponent;
  let fixture: ComponentFixture<UploadHrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadHrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadHrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
