export class Login {
    username: string;
    password: string;
    id: number;
	empId: string;
    roll: number;
    status: number;
}