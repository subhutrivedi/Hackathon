import { Injectable } from '@angular/core';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MockapiService {
  mockapi: Array<object> = [
    { document: 'Aadhar card', url:'Aadharcard.pdf' },
    { document: 'Pancard', url:'pancard.pdf' },
    { document: 'HSC marksheet', url:'HSC.pdf' },
    { document: 'Passport' , url:'passport.jpeg'},
    { document: 'Background Verification', url:'details.pdf' }
  ];

  constructor() { }

  get() {
    return of(this.mockapi);
  }
}
