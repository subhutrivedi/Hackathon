import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
//import { AuthenticationService } from './auth.service';


@Component({
  selector: 'app-login1',
  templateUrl: './login1.component.html',
  styleUrls: ['./login1.component.css']
})

export class LoginComponent1 implements OnInit {

  username: string;
  password : string;
  errorMessage = 'Invalid Credentials';
  successMessage: string;
  invalidLogin = false;
  loginSuccess = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    //private authenticationService: AuthenticationService
    ) {   }

  ngOnInit() {
  }

  handleLogin() {
    /*this.authenticationService.authenticationDBService(this.username, this.password).subscribe((result)=> {
      this.invalidLogin = false;
      this.loginSuccess = true;
      this.successMessage = 'Login Successful.';
      this.router.navigate(['/employees']);
    }, () => {
      this.invalidLogin = true;
      this.loginSuccess = false;
    });      
  }*/
  this.router.navigate(['/employee-dashboard']);
}
}


