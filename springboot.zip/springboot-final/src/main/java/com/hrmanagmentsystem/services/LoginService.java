package com.hrmanagmentsystem.services;

import com.hrmanagmentsystem.bean.LoginDetails;

public interface LoginService {

	LoginDetails getLoginDetails(String username, String password);

	int deleteUserAccess(LoginDetails loginDetails);

}
